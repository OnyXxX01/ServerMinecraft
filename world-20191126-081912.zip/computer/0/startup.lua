while true do
term.clear()
term.setCursorPos(1, 1)
print("Assword")
local input = read(":)")
if input == "1337228" then
    redstone.setOutput("back", true)
    sleep(3)
    redstone.setOutput("back", false)
    end
end

